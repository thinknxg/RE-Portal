import frappe
from frappe.model.document import Document


class LeadSourceRE(Document):
    pass
